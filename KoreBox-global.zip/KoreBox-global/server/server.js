// KoreBox v1 — Node.js REST + WebSocket backend.
// Для production используйте HTTPS/WSS, постоянный диск и надёжный JWT_SECRET.
const express = require('express');
const http = require('http');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Установите JWT_SECRET длиной не менее 32 символов.');
  process.exit(1);
}
const app = express();
app.use(express.json({limit:'32kb'}));
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');next()});
const db = new Database(process.env.DB_PATH || path.join(__dirname,'korebox.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY, nick TEXT NOT NULL, nick_key TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, secret_hash TEXT NOT NULL, about TEXT NOT NULL DEFAULT '',
 registered TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS recent_games(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
 name TEXT NOT NULL, played_at TEXT NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS chat_history(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, nick TEXT NOT NULL,
 text TEXT NOT NULL, sent_at TEXT NOT NULL
);
`);
const byNick = db.prepare('SELECT * FROM users WHERE nick_key=?');
const byId = db.prepare('SELECT * FROM users WHERE id=?');
const insertUser = db.prepare('INSERT INTO users(id,nick,nick_key,password_hash,secret_hash,about,registered) VALUES(?,?,?,?,?,?,?)');
const getRecent = db.prepare('SELECT name, played_at AS date FROM recent_games WHERE user_id=? ORDER BY id DESC LIMIT 10');
const recentInsert = db.prepare('INSERT INTO recent_games(user_id,name,played_at) VALUES(?,?,?)');
const chatInsert = db.prepare('INSERT INTO chat_history(user_id,nick,text,sent_at) VALUES(?,?,?,?)');
const chatLast = db.prepare('SELECT nick,text,sent_at AS date FROM chat_history ORDER BY id DESC LIMIT 30');

function safeUser(u){return {nick:u.nick,about:u.about,registered:u.registered,recent:getRecent.all(u.id)}}
function tokenFor(u){return jwt.sign({sub:u.id,nick:u.nick},JWT_SECRET,{expiresIn:'7d',issuer:'korebox'})}
function auth(req,res,next){
 const raw=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
 try{const p=jwt.verify(raw,JWT_SECRET,{issuer:'korebox'});const u=byId.get(p.sub);if(!u)return res.status(401).json({error:'Аккаунт не найден'});req.user=u;next()}
 catch{return res.status(401).json({error:'Сессия истекла или токен неверен'})}
}
function cleanNick(n){return typeof n==='string'?n.trim():''}
function validNick(n){return /^[\p{L}\p{N}_-]{3,16}$/u.test(n)}
function hashSecret(s){return crypto.createHash('sha256').update(String(s).trim().toLocaleLowerCase('ru')).digest('hex')}
const rate = new Map();
function limited(key,ms){const now=Date.now(),prev=rate.get(key)||0;if(now-prev<ms)return false;rate.set(key,now);return true}

app.get('/health',(req,res)=>res.json({ok:true,service:'KoreBox',version:1}));
app.post('/api/register',async(req,res)=>{
 try{
  const nick=cleanNick(req.body.nick), password=String(req.body.password||''), secret=String(req.body.secretAnswer||'').trim();
  if(!validNick(nick))return res.status(400).json({error:'Ник: 3–16 символов, буквы, цифры, _ или -'});
  if(password.length<6||password.length>200)return res.status(400).json({error:'Пароль должен содержать минимум 6 символов'});
  if(secret.length<1||secret.length>100)return res.status(400).json({error:'Укажи ответ на секретный вопрос'});
  if(byNick.get(nick.toLocaleLowerCase('ru')))return res.status(409).json({error:'Этот ник уже занят'});
  const u={id:crypto.randomUUID(),nick,nick_key:nick.toLocaleLowerCase('ru'),password_hash:await bcrypt.hash(password,12),secret_hash:hashSecret(secret),about:'',registered:new Date().toISOString()};
  insertUser.run(u.id,u.nick,u.nick_key,u.password_hash,u.secret_hash,u.about,u.registered);
  res.status(201).json({token:tokenFor(u),user:safeUser(u)});
 }catch(e){console.error(e);res.status(500).json({error:'Не удалось создать аккаунт'})}
});
app.post('/api/login',async(req,res)=>{
 try{const nick=cleanNick(req.body.nick),password=String(req.body.password||'');const u=byNick.get(nick.toLocaleLowerCase('ru'));
 if(!u||!await bcrypt.compare(password,u.password_hash))return res.status(401).json({error:'Неверный ник или пароль'});
 res.json({token:tokenFor(u),user:safeUser(u)});
 }catch(e){res.status(500).json({error:'Ошибка входа'})}
});
app.post('/api/recovery',async(req,res)=>{
 try{
  const nick=cleanNick(req.body.nick),secret=String(req.body.secretAnswer||''),np=String(req.body.newPassword||'');
  const u=byNick.get(nick.toLocaleLowerCase('ru'));
  if(!u)return res.status(404).json({error:'Аккаунт не найден'});
  if(hashSecret(secret)!==u.secret_hash)return res.status(403).json({error:'Ответ на секретный вопрос неверен'});
  if(np.length<6||np.length>200)return res.status(400).json({error:'Новый пароль должен содержать 6–200 символов'});
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(await bcrypt.hash(np,12),u.id);
  res.json({ok:true});
 }catch(e){res.status(500).json({error:'Не удалось восстановить аккаунт'})}
});
app.get('/api/profile',auth,(req,res)=>res.json(safeUser(req.user)));
app.put('/api/profile',auth,(req,res)=>{
 const about=String(req.body.about||'').slice(0,200);
 db.prepare('UPDATE users SET about=? WHERE id=?').run(about,req.user.id);
 res.json(safeUser(byId.get(req.user.id)));
});
app.post('/api/games/recent',auth,(req,res)=>{
 const name=String(req.body.name||'').slice(0,80);
 if(name!=='Скейт Парк')return res.status(400).json({error:'Неизвестная игра'});
 recentInsert.run(req.user.id,name,new Date().toISOString());
 res.json({ok:true,recent:getRecent.all(req.user.id)});
});
app.get('/api/games/recent',auth,(req,res)=>res.json({recent:getRecent.all(req.user.id)}));

// В этой версии HTML-клиент раздаётся тем же сервером, чтобы CORS не мешал.
app.use(express.static(path.join(__dirname,'public')));
const server=http.createServer(app);
const wss=new WebSocketServer({noServer:true});
const players=new Map(), wsClients=new Set();
server.on('upgrade',(req,socket,head)=>{
 const url=new URL(req.url,'http://localhost');
 if(url.pathname!=='/ws'){socket.destroy();return}
 wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
function send(ws,type,payload){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({type,payload}))}
function broadcast(type,payload,except=null){for(const c of wsClients)if(c!==except)send(c,type,payload)}
wss.on('connection',(ws,req)=>{
 const url=new URL(req.url,'http://localhost');let u;
 try{const p=jwt.verify(url.searchParams.get('token')||'',JWT_SECRET,{issuer:'korebox'});u=byId.get(p.sub)}catch{}
 if(!u){ws.close(1008,'Требуется вход');return}
 const client={ws,id:u.id,nick:u.nick,x:80,y:314,lastChat:0};wsClients.add(client);players.set(u.id,client);
 send(ws,'chat_history',chatLast.all().reverse());
 send(ws,'players',Array.from(players.values()).filter(p=>p.id!==u.id).map(p=>({id:p.id,nick:p.nick,x:p.x,y:p.y})));
 broadcast('player_join',{id:u.id,nick:u.nick,x:client.x,y:client.y},client);
 ws.on('message',raw=>{
  if(raw.length>4096)return;
  let m;try{m=JSON.parse(raw.toString())}catch{return}
  if(!m||typeof m.type!=='string')return;
  if(m.type==='chat'){
   const text=String(m.payload&&m.payload.text||'').trim();
   if(!text||text.length>200||Date.now()-client.lastChat<2000)return;
   client.lastChat=Date.now();const at=new Date().toISOString();chatInsert.run(u.id,u.nick,text,at);
   // Держим последние 500 сообщений, чтобы база не росла бесконечно.
   db.prepare('DELETE FROM chat_history WHERE id NOT IN (SELECT id FROM chat_history ORDER BY id DESC LIMIT 500)').run();
   broadcast('chat',{nick:u.nick,text,date:at});
  }else if(m.type==='position'){
   const x=Number(m.payload&&m.payload.x),y=Number(m.payload&&m.payload.y);
   if(!Number.isFinite(x)||!Number.isFinite(y))return;
   client.x=Math.max(0,Math.min(864,x));client.y=Math.max(0,Math.min(374,y));
   broadcast('position',{id:u.id,nick:u.nick,x:client.x,y:client.y},client);
  }
 });
 ws.on('close',()=>{wsClients.delete(client);if(players.get(u.id)===client)players.delete(u.id);broadcast('player_leave',{id:u.id})});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`KoreBox server listening on ${PORT}`));
