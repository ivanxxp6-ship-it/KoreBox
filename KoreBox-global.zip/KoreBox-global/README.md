# KoreBox Global — HTML + сервер

## Что это
- `client/KoreBox.html` — HTML-клиент.
- `server/server.js` — Node.js REST + WebSocket сервер.
- Аккаунты, профиль, история игр и чат хранятся на сервере, а не в localStorage.
- В браузере локально сохраняется только адрес сервера и временный токен сессии.

## Запуск локально для проверки
Требуется Node.js 20+ и npm.

Linux/macOS:
```bash
cd server
npm install
export JWT_SECRET="$(openssl rand -hex 32)"
npm start
```

Windows PowerShell:
```powershell
cd server
npm install
$env:JWT_SECRET = [guid]::NewGuid().ToString() + [guid]::NewGuid().ToString()
npm start
```

Открой `http://localhost:8080/health` и убедись, что `ok: true`.
Для удобной раздачи HTML положи файл клиента в `server/public/KoreBox.html`, создав папку `public`.
Затем открой `http://localhost:8080/KoreBox.html`.

## Публикация в интернете
1. Разверни папку `server` на VPS с Node.js 20+ и постоянным диском.
2. Установи зависимости `npm install`.
3. Установи постоянный `JWT_SECRET` длиной минимум 32 символа.
4. Запусти `npm start` под менеджером процессов (например, systemd/PM2).
5. Настрой домен и HTTPS/WSS через Caddy/Nginx. WebSocket путь должен проксироваться на `/ws`.
6. Сохрани `client/KoreBox.html` в `server/public/KoreBox.html` и открывай HTML по HTTPS.
7. Если открываешь HTML с другого хоста, впиши адрес API в поле подключения; production лучше отдавать клиент и API с одного домена.

## API
- `GET /health`
- `POST /api/register` `{nick,password,secretAnswer}`
- `POST /api/login` `{nick,password}`
- `POST /api/recovery` `{nick,secretAnswer,newPassword}`
- `GET /api/profile` (Bearer token)
- `PUT /api/profile` `{about}` (Bearer token)
- `POST /api/games/recent` `{name:"Скейт Парк"}` (Bearer token)
- `GET /api/games/recent` (Bearer token)
- `WS /ws?token=JWT` — `chat`, `position`, `players`, `player_join`, `player_leave`

## Важные ограничения и безопасность
- Восстановление пароля по секретному ответу — упрощённая демо-схема, слабее восстановления по email с одноразовым кодом. Не используй важный пароль/ответ.
- Для публичного запуска добавь rate limiting на регистрацию/вход/recovery, CAPTCHA при необходимости, политику приватности, резервные копии и мониторинг.
- Не используй `http://` для публичного сайта: браузеры могут блокировать незашифрованный WebSocket/запросы. Используй HTTPS/WSS.
- SQLite требует постоянного диска. Не размещай базу на эфемерном файловом хранилище.
- Это HTML-версия прототипа; APK она не создаёт.
